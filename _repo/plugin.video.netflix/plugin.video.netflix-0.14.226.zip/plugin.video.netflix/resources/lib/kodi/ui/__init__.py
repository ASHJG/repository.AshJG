# -*- coding: utf-8 -*-
"""Kodi GUI stuff"""
# pylint: disable=wildcard-import
from __future__ import unicode_literals

from .dialogs import *
from .xmldialogs import *
